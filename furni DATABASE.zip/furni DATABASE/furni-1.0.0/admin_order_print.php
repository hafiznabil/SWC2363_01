<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once 'config/db_connection.php';

try {
    $conn = getDBConnection();

    // Validate and sanitize the order ID
    $orderId = filter_var($_GET['id'], FILTER_VALIDATE_INT);
    if (!$orderId) {
        throw new Exception("Invalid order ID");
    }

    // Fetch order details with user information
    $stmt = $conn->prepare("
        SELECT o.*, u.email, u.first_name, u.last_name
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        WHERE o.order_id = ?
    ");
    $stmt->execute([$orderId]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$order) {
        throw new Exception("Order not found");
    }

    // Fetch order items with product details
    $stmt = $conn->prepare("
        SELECT oi.*, p.name, p.price
        FROM order_items oi
        JOIN products p ON oi.product_id = p.product_id
        WHERE oi.order_id = ?
    ");
    $stmt->execute([$orderId]);
    $orderItems = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Order #<?php echo $orderId; ?> - Print</title>
    <style>
        body {
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            line-height: 1.6;
            margin: 40px auto;
            max-width: 800px;
            color: #333;
            background: #fff;
        }

        .header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 20px;
            border-bottom: 2px solid #eee;
        }

        .header h1 {
            color: #2c3e50;
            margin-bottom: 10px;
        }

        .order-info {
            background: #f8f9fa;
            padding: 25px;
            border-radius: 8px;
            margin-bottom: 30px;
        }

        .order-info h3 {
            margin-top: 0;
            color: #2c3e50;
        }

        table {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            margin-bottom: 30px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        }

        th,
        td {
            padding: 12px 15px;
            border: none;
            border-bottom: 1px solid #eee;
        }

        th {
            background-color: #2c3e50;
            color: white;
            font-weight: 500;
        }

        tr:last-child td {
            border-bottom: none;
        }

        .total {
            text-align: right;
            font-weight: 600;
            color: #2c3e50;
        }

        .no-print button {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            background: #2c3e50;
            color: white;
            cursor: pointer;
            margin-right: 10px;
            transition: background 0.3s ease;
        }

        .no-print button:hover {
            background: #34495e;
        }

        @media print {
            body {
                margin: 20px;
            }

            .no-print {
                display: none;
            }

            table {
                box-shadow: none;
            }
        }
    </style>
</head>

<body>
    <div class="header">
        <h1>Furni Store</h1>
        <h2>Order #<?php echo $orderId; ?></h2>
    </div>

    <div class="order-info">
        <h3>Customer Information</h3>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($order['email']); ?></p>
        <p><strong>Order Date:</strong> <?php echo date('F j, Y', strtotime($order['order_date'])); ?></p>
        <p><strong>Status:</strong> <?php echo htmlspecialchars($order['status']); ?></p>
    </div>

    <h3>Order Items</h3>
    <table>
        <thead>
            <tr>
                <th>Product</th>
                <th>Quantity</th>
                <th>Price</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $total = 0;
            foreach ($orderItems as $item):
                $subtotal = $item['quantity'] * $item['price'];
                $total += $subtotal;
            ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['name']); ?></td>
                    <td><?php echo htmlspecialchars($item['quantity']); ?></td>
                    <td>$<?php echo number_format($item['price'], 2); ?></td>
                    <td>$<?php echo number_format($subtotal, 2); ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3" class="total">Total:</td>
                <td>$<?php echo number_format($total, 2); ?></td>
            </tr>
        </tbody>
    </table>

    <div class="no-print">
        <button onclick="window.print()">Print Order</button>
        <button onclick="window.close()">Close</button>
    </div>
</body>

</html>