<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once 'config/db_connection.php';

try {
    $conn = getDBConnection();

    // Fetch all orders with user information and order items
    $stmt = $conn->query("
        SELECT 
            o.order_id,
            o.order_date,
            o.status,
            o.total_amount,
            u.email,
            u.first_name,
            u.last_name,
            GROUP_CONCAT(CONCAT(p.name, ' (', oi.quantity, ')') SEPARATOR '; ') as items
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        LEFT JOIN products p ON oi.product_id = p.product_id
        GROUP BY o.order_id
        ORDER BY o.order_date DESC
    ");

    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Set headers for CSV download
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="orders_export_' . date('Y-m-d') . '.csv"');

    // Create output stream
    $output = fopen('php://output', 'w');

    // Add UTF-8 BOM for proper Excel encoding
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

    // Add headers
    fputcsv($output, [
        'Order ID',
        'Date',
        'Customer Name',
        'Email',
        'Status',
        'Total Amount',
        'Items'
    ]);

    // Add data rows
    foreach ($orders as $order) {
        fputcsv($output, [
            '#' . $order['order_id'],
            date('Y-m-d H:i', strtotime($order['order_date'])),
            $order['first_name'] . ' ' . $order['last_name'],
            $order['email'],
            $order['status'],
            '$' . number_format($order['total_amount'], 2),
            $order['items']
        ]);
    }

    fclose($output);
    exit;
} catch (Exception $e) {
    die("Error exporting orders: " . $e->getMessage());
}
