<?php
session_start();
require_once 'config/db_connection.php';

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

try {
    // Get database connection
    $conn = getDBConnection();

    // Fetch all newsletter subscribers
    $query = "SELECT * FROM newsletter_subscribers ORDER BY subscribed_at DESC";
    $stmt = $conn->query($query);

    // Get total subscribers count
    $totalSubscribers = $conn->query("SELECT COUNT(*) FROM newsletter_subscribers")->fetchColumn();

    // Get subscribers from last 30 days
    $recentSubscribers = $conn->query("SELECT COUNT(*) FROM newsletter_subscribers WHERE subscribed_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetchColumn();
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Newsletter Management - Furni</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }

        .sidebar a {
            color: white;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .card-dashboard {
            transition: transform 0.2s;
        }

        .card-dashboard:hover {
            transform: translateY(-5px);
        }
    </style>
</head>

<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar p-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Furni Admin</h4>
                </div>
                <div class="list-group">
                    <a href="admin_dashboard.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                    <a href="admin_products.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-box me-2"></i> Products
                    </a>
                    <a href="admin_orders.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-shopping-cart me-2"></i> Orders
                    </a>
                    <a href="admin_users.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-users me-2"></i> Users
                    </a>
                    <a href="admin_newsletter.php" class="list-group-item list-group-item-action active bg-dark">
                        <i class="fas fa-envelope me-2"></i> Newsletter
                    </a>
                    <a href="logout.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>Newsletter Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <button type="button" class="btn btn-sm btn-primary me-2" onclick="composeMail()">
                            <i class="fas fa-paper-plane me-2"></i>Send Newsletter
                        </button>
                        <button type="button" class="btn btn-sm btn-success" onclick="exportSubscribers()">
                            <i class="fas fa-download me-2"></i>Export List
                        </button>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-6 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2 card-dashboard">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                            Total Subscribers</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $totalSubscribers; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2 card-dashboard">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                            New Subscribers (30 days)</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $recentSubscribers; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-chart-line fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Subscribers Table -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">Newsletter Subscribers</h6>
                        <div class="input-group w-25">
                            <input type="text" class="form-control" placeholder="Search..." id="searchInput" onkeyup="searchSubscribers()">
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" id="subscribersTable">
                                <thead>
                                    <tr>
                                        <th><input type="checkbox" id="selectAll" onclick="toggleAllCheckboxes()"></th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Subscribed Date</th>
                                        <th>Status</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($subscriber = $stmt->fetch(PDO::FETCH_ASSOC)) : ?>
                                        <tr>
                                            <td><input type="checkbox" class="subscriber-checkbox"></td>
                                            <td><?php echo htmlspecialchars($subscriber['name']); ?></td>
                                            <td><?php echo htmlspecialchars($subscriber['email']); ?></td>
                                            <td><?php echo date('Y-m-d', strtotime($subscriber['subscribed_at'])); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $subscriber['status'] === 'active' ? 'success' : 'warning'; ?>">
                                                    <?php echo ucfirst($subscriber['status']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <button class="btn btn-sm btn-danger" onclick="unsubscribe(<?php echo $subscriber['subscriber_id']; ?>)">
                                                    <i class="fas fa-user-minus"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="js/bootstrap.bundle.min.js"></script>
    <script>
        function composeMail() {
            // Implement newsletter composition functionality
            window.location.href = 'admin_compose_newsletter.php';
        }

        function exportSubscribers() {
            // Implement export functionality
            window.location.href = 'export_subscribers.php';
        }

        function unsubscribe(id) {
            if (confirm('Are you sure you want to unsubscribe this email?')) {
                // Implement unsubscribe functionality using AJAX
                fetch(`api/newsletter/unsubscribe/${id}`, {
                        method: 'POST'
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            location.reload();
                        }
                    })
                    .catch(error => console.error('Error:', error));
            }
        }

        function toggleAllCheckboxes() {
            const checkboxes = document.getElementsByClassName('subscriber-checkbox');
            const selectAll = document.getElementById('selectAll');
            for (let checkbox of checkboxes) {
                checkbox.checked = selectAll.checked;
            }
        }

        function searchSubscribers() {
            const input = document.getElementById('searchInput');
            const filter = input.value.toLowerCase();
            const table = document.getElementById('subscribersTable');
            const tr = table.getElementsByTagName('tr');

            for (let i = 1; i < tr.length; i++) {
                const nameCol = tr[i].getElementsByTagName('td')[1]; // Name column
                const emailCol = tr[i].getElementsByTagName('td')[2]; // Email column
                if (nameCol && emailCol) {
                    const nameValue = nameCol.textContent || nameCol.innerText;
                    const emailValue = emailCol.textContent || emailCol.innerText;
                    const matches = nameValue.toLowerCase().indexOf(filter) > -1 ||
                        emailValue.toLowerCase().indexOf(filter) > -1;
                    tr[i].style.display = matches ? '' : 'none';
                }
            }
        }
    </script>
</body>

</html>