<?php
session_start();
require_once 'config/db_connection.php';

// Check if user is logged in and order exists
if (!isset($_SESSION['user_id']) || !isset($_SESSION['order_id'])) {
    header('Location: login.php');
    exit();
}

try {
    $pdo = getDBConnection();

    // Fetch order details with items
    $order_query = "SELECT o.*, u.email, u.first_name, u.last_name,
                    p.name as product_name, oi.quantity, oi.price,
                    o.discount_amount, o.total_amount
                    FROM orders o 
                    JOIN users u ON o.user_id = u.user_id 
                    JOIN order_items oi ON o.order_id = oi.order_id
                    JOIN products p ON oi.product_id = p.product_id
                    WHERE o.order_id = ? AND o.user_id = ? AND o.payment_status = 'pending'";

    $stmt = $pdo->prepare($order_query);
    $stmt->execute([$_SESSION['order_id'], $_SESSION['user_id']]);
    $order_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (empty($order_items)) {
        header('Location: checkout.php');
        exit();
    }

    // Calculate totals
    $subtotal = array_sum(array_map(function ($item) {
        return $item['price'] * $item['quantity'];
    }, $order_items));

    // Get discount and final total from the order
    $discount_amount = $order_items[0]['discount_amount'] ?? 0;

    // Calculate the actual total by subtracting discount from subtotal
    $total = $subtotal - $discount_amount;

    // Process payment
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['process_payment'])) {
        // Validate payment details
        $card_number = preg_replace('/\D/', '', $_POST['card_number']);
        $card_holder = trim($_POST['card_holder']);
        $expiry_month = $_POST['expiry_month'];
        $expiry_year = $_POST['expiry_year'];
        $cvv = preg_replace('/\D/', '', $_POST['cvv']);

        $errors = [];

        // Enhanced validation
        if (strlen($card_number) !== 16) {
            $errors[] = "Invalid card number - must be 16 digits";
        }
        if (empty($card_holder)) {
            $errors[] = "Card holder name is required";
        }
        if (strlen($cvv) !== 3) {
            $errors[] = "Invalid CVV - must be 3 digits";
        }

        // Validate expiry date
        $current_date = new DateTime();
        $expiry_date = new DateTime("$expiry_year-$expiry_month-01");
        if ($expiry_date <= $current_date) {
            $errors[] = "Card has expired";
        }

        if (empty($errors)) {
            try {
                $pdo->beginTransaction();

                // Update order status
                $update_order = "UPDATE orders SET 
                    payment_status = 'paid',
                    payment_date = NOW(),
                    payment_method = 'credit_card',
                    status = 'processing'
                    WHERE order_id = ? AND user_id = ?";

                $stmt = $pdo->prepare($update_order);
                $stmt->execute([$_SESSION['order_id'], $_SESSION['user_id']]);

                // Record payment
                $payment_query = "INSERT INTO payments (
                    order_id, amount, card_number, card_holder, 
                    payment_status, payment_date
                ) VALUES (?, ?, ?, ?, 'completed', NOW())";

                $masked_card = '**** **** **** ' . substr($card_number, -4);
                $stmt = $pdo->prepare($payment_query);
                $stmt->execute([
                    $_SESSION['order_id'],
                    $total,
                    $masked_card,
                    $card_holder
                ]);

                $pdo->commit();

                // Store the order ID before clearing session
                $completed_order_id = $_SESSION['order_id'];

                // Clear relevant session data
                unset($_SESSION['order_id']);
                unset($_SESSION['order_total']);
                unset($_SESSION['cart']);
                unset($_SESSION['coupon_id']);
                unset($_SESSION['coupon_discount']);

                // Redirect to thank you page with the order ID
                header("Location: thankyou.php?order_id=" . $completed_order_id);
                exit();
            } catch (Exception $e) {
                $pdo->rollBack();
                error_log("Payment Processing Error: " . $e->getMessage());
                $errors[] = "Payment processing failed. Please try again.";
            }
        }
    }
} catch (Exception $e) {
    error_log("Payment Error: " . $e->getMessage());
    $errors[] = "An error occurred. Please try again later.";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment - Furni</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <style>
        .payment-container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .order-summary {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 4px;
            margin-bottom: 30px;
        }

        .table th,
        .table td {
            vertical-align: middle;
        }

        .total-amount {
            font-size: 1.2em;
            color: #000;
            font-weight: bold;
        }
    </style>
</head>

<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3>Payment Details</h3>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($errors)): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php foreach ($errors as $error): ?>
                                        <li><?= htmlspecialchars($error) ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <!-- Order Summary -->
                        <div class="order-summary mb-4">
                            <h4>Order Summary</h4>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Product</th>
                                        <th>Quantity</th>
                                        <th>Price</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($order_items as $item): ?>
                                        <tr>
                                            <td><?= htmlspecialchars($item['product_name']) ?></td>
                                            <td><?= $item['quantity'] ?></td>
                                            <td>RM<?= number_format($item['price'], 2) ?></td>
                                            <td>RM<?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                    <tr>
                                        <td colspan="3" class="text-end"><strong>Subtotal:</strong></td>
                                        <td><strong>RM<?= number_format($subtotal, 2) ?></strong></td>
                                    </tr>
                                    <?php if ($discount_amount > 0): ?>
                                        <tr>
                                            <td colspan="3" class="text-end"><strong>Discount:</strong></td>
                                            <td><strong>-RM<?= number_format($discount_amount, 2) ?></strong></td>
                                        </tr>
                                    <?php endif; ?>
                                    <tr>
                                        <td colspan="3" class="text-end"><strong>Total Amount:</strong></td>
                                        <td><strong>RM<?= number_format($total, 2) ?></strong></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <!-- Payment Form -->
                        <form method="POST" action="">
                            <div class="mb-3">
                                <label for="card_number" class="form-label">Card Number</label>
                                <input type="text" class="form-control" id="card_number" name="card_number"
                                    required maxlength="19" placeholder="1234 5678 9012 3456">
                            </div>

                            <div class="mb-3">
                                <label for="card_holder" class="form-label">Card Holder Name</label>
                                <input type="text" class="form-control" id="card_holder" name="card_holder" required>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label for="expiry_month" class="form-label">Expiry Month</label>
                                    <select class="form-control" id="expiry_month" name="expiry_month" required>
                                        <?php for ($i = 1; $i <= 12; $i++): ?>
                                            <option value="<?= sprintf('%02d', $i) ?>"><?= sprintf('%02d', $i) ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="expiry_year" class="form-label">Expiry Year</label>
                                    <select class="form-control" id="expiry_year" name="expiry_year" required>
                                        <?php
                                        $current_year = date('Y');
                                        for ($i = $current_year; $i <= $current_year + 10; $i++):
                                        ?>
                                            <option value="<?= $i ?>"><?= $i ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="cvv" class="form-label">CVV</label>
                                    <input type="text" class="form-control" id="cvv" name="cvv"
                                        required maxlength="3" placeholder="123">
                                </div>
                            </div>

                            <button type="submit" name="process_payment" class="btn btn-primary btn-lg w-100">
                                Pay RM<?= number_format($total, 2) ?>
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Card number formatting
        document.getElementById('card_number').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 16) value = value.substr(0, 16);
            value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
            e.target.value = value;
        });

        // CVV validation
        document.getElementById('cvv').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 3) value = value.substr(0, 3);
            e.target.value = value;
        });

        // Card holder name validation
        document.getElementById('card_holder').addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/[^a-zA-Z\s]/g, '');
        });
    </script>
</body>

</html>