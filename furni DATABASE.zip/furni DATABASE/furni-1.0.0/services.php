<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">

	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap4" />

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
	<link href="css/tiny-slider.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<title>Furni</title>
</head>

<body>

	<!-- Start Header/Navigation -->
	<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

		<div class="container">
			<a class="navbar-brand" href="index.php">Furni<span>.</span></a>

			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarsFurni">
				<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
					<li class="nav-item">
						<a class="nav-link" href="index.php">Home</a>
					</li>
					<li><a class="nav-link" href="shop.php">Shop</a></li>
					<li><a class="nav-link" href="about.php">About us</a></li>
					<li class="active"><a class="nav-link" href="services.php">Services</a></li>
					<li><a class="nav-link" href="blog.php">Blog</a></li>
					<li><a class="nav-link" href="contact.php">Contact us</a></li>
				</ul>

				<ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
							<img src="images/user.svg" alt="User">
						</a>
						<?php if (isset($_SESSION['user_id'])): ?>
							<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
								<li><a class="dropdown-item" href="account/profile_settings.php">Profile Settings</a></li>
								<li><a class="dropdown-item" href="account/orders.php">My Orders</a></li>
								<li>
									<hr class="dropdown-divider">
								</li>
								<li><a class="dropdown-item" href="logout.php">Logout</a></li>
							</ul>
						<?php else: ?>
							<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
								<li><a class="dropdown-item" href="account/profile_settings.php">Profile Settings</a></li>
								<li><a class="dropdown-item" href="account/orders.php">My Orders</a></li>
								<li><a class="dropdown-item" href="logout.php">Logout</a></li>
							</ul>
						<?php endif; ?>
					</li>
					<li><a class="nav-link" href="cart.php"><img src="images/cart.svg"></a></li>
				</ul>
			</div>
		</div>

	</nav>
	<!-- End Header/Navigation -->

	<!-- Start Hero Section -->
	<div class="hero">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-5">
					<div class="intro-excerpt">
						<h1>Services</h1>
						<p class="mb-4">we make it easy to find quality furniture that fits your style. Our wide selection includes customizable sofas, chairs, tables, and more. Our design experts can help you plan layouts and choose pieces to perfect your space. Shop easily on our website, with fast, reliable delivery across Malaysia and dedicated after-sales support. Transform your home or office with Furni’s stylish and functional furniture.</p>
						<p><a href="" class="btn btn-secondary me-2">Shop Now</a><a href="#" class="btn btn-white-outline">Explore</a></p>
					</div>
				</div>
				<div class="col-lg-7">
					<div class="hero-img-wrap">
						<img src="images/couch.png" class="img-fluid">
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Hero Section -->



	<!-- Start Why Choose Us Section -->
	<div class="why-choose-section">
		<div class="container">


			<div class="row my-5">
				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">
						<div class="icon">
							<img src="images/truck.svg" alt="Image" class="imf-fluid">
						</div>
						<h3>Fast &amp; Free Shipping</h3>
						<p>Getting Your Dream Furniture Should Be Effortless!</p>
					</div>
				</div>

				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">
						<div class="icon">
							<img src="images/bag.svg" alt="Image" class="imf-fluid">
						</div>
						<h3>Easy to Shop</h3>
						<p>Discover Your Perfect Furniture with a Seamless Shopping Experience!</p>
					</div>
				</div>

				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">
						<div class="icon">
							<img src="images/support.svg" alt="Image" class="imf-fluid">
						</div>
						<h3>24/7 Support</h3>
						<p>Customers can reach out at any time, whether it’s day or night. This flexibility ensures that support is always available when needed.</p>
					</div>
				</div>

				<div class="col-6 col-md-6 col-lg-3 mb-4">
					<div class="feature">
						<div class="icon">
							<img src="images/return.svg" alt="Image" class="imf-fluid">
						</div>
						<h3>Hassle Free Returns</h3>
						<p>We prioritize your satisfaction. Our hassle-free return policy is designed with you in mind, ensuring a stress-free shopping experience.</p>
					</div>
				</div>

			</div>

		</div>
	</div>
	<!-- End Why Choose Us Section -->

	<!-- Start Product Section -->
	<div class="product-section pt-0">
		<div class="container">
			<div class="row">

				<!-- Start Column 1 -->
				<div class="col-md-12 col-lg-3 mb-5 mb-lg-0">
					<h2 class="mb-4 section-title">Crafted with excellent material.</h2>
					<p class="mb-4">Expertly crafted from premium materials, our furniture combines durability with elegance to elevate any space.</p>
					<p><a href="#" class="btn">Explore</a></p>
				</div>
				<!-- End Column 1 -->

				<!-- Start Column 2 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
					<a class="product-item" href="#">
						<img src="images/product-1.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Nordic Chair</h3>
						<strong class="product-price">RM 50.00</strong>

						<span class="icon-cross">
							<img src="images/cross.svg" class="img-fluid">
						</span>
					</a>
				</div>
				<!-- End Column 2 -->

				<!-- Start Column 3 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
					<a class="product-item" href="#">
						<img src="images/product-2.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Kruzo Aero Chair</h3>
						<strong class="product-price">RM 78.00</strong>

						<span class="icon-cross">
							<img src="images/cross.svg" class="img-fluid">
						</span>
					</a>
				</div>
				<!-- End Column 3 -->

				<!-- Start Column 4 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5 mb-md-0">
					<a class="product-item" href="#">
						<img src="images/product-3.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Ergonomic Chair</h3>
						<strong class="product-price">RM 43.00</strong>

						<span class="icon-cross">
							<img src="images/cross.svg" class="img-fluid">
						</span>
					</a>
				</div>
				<!-- End Column 4 -->

			</div>
		</div>
	</div>
	<!-- End Product Section -->

	<!-- Start Testimonial Slider -->
	<div class="testimonial-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-7 mx-auto text-center">
					<h2 class="section-title">Testimonials</h2>
				</div>
			</div>

			<div class="row justify-content-center">
				<div class="col-lg-12">
					<div class="testimonial-slider-wrap text-center">

						<div id="testimonial-nav">
							<span class="prev" data-controls="prev"><span class="fa fa-chevron-left"></span></span>
							<span class="next" data-controls="next"><span class="fa fa-chevron-right"></span></span>
						</div>

						<div class="testimonial-slider">

							<div class="item">
								<div class="row justify-content-center">
									<div class="col-lg-8 mx-auto">

										<div class="testimonial-block text-center">
											<blockquote class="mb-5">
												<p>&ldquo;"I stumbled upon the Furni blog while looking for design inspiration, and I was blown away by the quality of advice! Their tips on choosing the right furniture for small spaces helped me transform my living room. Now, I'm a regular reader!"&rdquo;</p>
											</blockquote>

											<div class="author-info">
												<div class="author-pic">
													<img src="images/person-1.png" alt="Sara T" class="img-fluid">
												</div>
												<h3 class="font-weight-bold">Sara T</h3>
												<span class="position d-block mb-3">BOSS, Owner-Founder,Furni.</span>
											</div>
										</div>

									</div>
								</div>
							</div>
							<!-- END item -->

							<div class="item">
								<div class="row justify-content-center">
									<div class="col-lg-8 mx-auto">

										<div class="testimonial-block text-center">
											<blockquote class="mb-5">
												<p>&ldquo;"The Furni blog is my go-to for interior design tips and furniture care advice. Thanks to their helpful articles, I finally found the perfect color palette for my home, and my furniture has never looked better!".&rdquo;</p>
											</blockquote>

											<div class="author-info">
												<div class="author-pic">
													<img src="images/person-1.png" alt="James R" class="img-fluid">
												</div>
												<h3 class="font-weight-bold">James R</h3>
												<span class="position d-block mb-3">CEO, Co-Founder, Furni.</span>
											</div>
										</div>

									</div>
								</div>
							</div>
							<!-- END item -->

							<div class="item">
								<div class="row justify-content-center">
									<div class="col-lg-8 mx-auto">

										<div class="testimonial-block text-center">
											<blockquote class="mb-5">
												<p>&ldquo;"I love the variety of topics on the Furni blog! From style trends to practical maintenance tips, it’s got everything a furniture lover needs. The posts are well-written, informative, and always inspire me to try new ideas in my home.".&rdquo;</p>
											</blockquote>

											<div class="author-info">
												<div class="author-pic">
													<img src="images/person-1.png" alt="Linda P" class="img-fluid">
												</div>
												<h3 class="font-weight-bold">Linda P</h3>
												<span class="position d-block mb-3">CED, Furni-Founder, Furni.</span>
											</div>
										</div>

									</div>
								</div>
							</div>
							<!-- END item -->

						</div>

					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Testimonial Slider -->

	<!-- Start Footer Section -->
	<footer class="footer-section">
		<div class="container relative">

			<div class="sofa-img">
				<img src="images/sofa.png" alt="Image" class="img-fluid">
			</div>

			<div class="row">
				<div class="col-lg-8">
					<div class="subscription-form">
						<h3 class="d-flex align-items-center">
							<span class="me-1"><img src="./images/envelope-outline.svg" alt="Image" class="img-fluid"></span>
							<span>Subscribe to Newsletter</span>
						</h3>

						<?php
						if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['subscribe'])) {
							// Database connection
							$conn = new mysqli("localhost", "root", "", "furni_store");

							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							}

							// Get and sanitize input
							$name = $conn->real_escape_string($_POST['subscriber_name']);
							$email = $conn->real_escape_string($_POST['subscriber_email']);

							// Check if email already exists
							$checkEmail = $conn->query("SELECT email FROM newsletter_subscribers WHERE email = '$email'");

							if ($checkEmail->num_rows > 0) {
								echo '<div class="alert alert-warning alert-dismissible fade show" role="alert" id="subscribeAlert">
										This email is already subscribed!
										<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
									  </div>';
							} else {
								// Insert new subscriber
								$sql = "INSERT INTO newsletter_subscribers (name, email) VALUES ('$name', '$email')";

								if ($conn->query($sql) === TRUE) {
									echo '<div class="alert alert-success alert-dismissible fade show" role="alert" id="subscribeAlert">
											Thank you for subscribing!
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
										  </div>';
								} else {
									echo '<div class="alert alert-danger alert-dismissible fade show" role="alert" id="subscribeAlert">
											Error: ' . $conn->error . '
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
										  </div>';
								}
							}



							$conn->close();
						}
						?>

						<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="row g-3">
							<div class="col-auto">
								<input type="text" name="subscriber_name" class="form-control" placeholder="Enter your name" required>
							</div>
							<div class="col-auto">
								<input type="email" name="subscriber_email" class="form-control" placeholder="Enter your email" required>
							</div>
							<div class="col-auto">
								<button type="submit" name="subscribe" class="btn btn-primary">
									<span class="fa fa-paper-plane"></span>
								</button>
							</div>
						</form>

					</div>
				</div>
			</div>

			<div class="row g-5 mb-5">
				<div class="col-lg-4">
					<div class="mb-4 footer-logo-wrap"><a href="#" class="footer-logo">Furni<span>.</span></a></div>
					<p class="mb-4">Furni offers a curated collection of modern, stylish furniture designed to enhance your home. Our high-quality pieces combine comfort and aesthetics, crafted from sustainable materials for durability and eco-friendliness. Transform your living space with Furni’s innovative designs that reflect your unique style.</p>

					<ul class="list-unstyled custom-social">
						<li><a href="#"><span class="fa fa-brands fa-facebook-f"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-twitter"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-instagram"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-linkedin"></span></a></li>
					</ul>
				</div>

				<div class="col-lg-8">
					<div class="row links-wrap">
						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">About us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Blog</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">Support</a></li>
								<li><a href="#">Knowledge base</a></li>
								<li><a href="#">Live chat</a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>
					</div>
				</div>

			</div>

			<div class="border-top copyright">
				<div class="row pt-4">
					<div class="col-lg-6">
						<p class="mb-2 text-center text-lg-start">Furni &copy;<script>
								document.write(new Date().getFullYear());
							</script>. All Rights Reserved. &mdash; Designed with love by <a href="#">NABIL</a>
						</p>
					</div>

					<div class="col-lg-6 text-center text-lg-end">
						<ul class="list-unstyled d-inline-flex ms-auto">
							<li class="me-4"><a href="#">Terms &amp; Conditions</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>
					</div>

				</div>
			</div>

		</div>
	</footer>
	<!-- End Footer Section -->


	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/tiny-slider.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>