<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once 'config/db_connection.php';

try {
    $conn = getDBConnection();

    // Fetch summary statistics
    $userCount = $conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
    $orderCount = $conn->query("SELECT COUNT(*) FROM orders")->fetchColumn();
    $productCount = $conn->query("SELECT COUNT(*) FROM products")->fetchColumn();
    $totalRevenue = $conn->query("SELECT COALESCE(SUM(total_amount), 0) FROM orders")->fetchColumn();

    // Fetch recent orders
    $recentOrders = $conn->query("
        SELECT o.*, u.email 
        FROM orders o 
        JOIN users u ON o.user_id = u.user_id 
        ORDER BY order_date DESC 
        LIMIT 5
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Add new functions for CRUD operations
function addRecord($conn, $table, $data)
{
    try {
        $columns = implode(", ", array_keys($data));
        $values = ":" . implode(", :", array_keys($data));
        $sql = "INSERT INTO $table ($columns) VALUES ($values)";
        $stmt = $conn->prepare($sql);
        return $stmt->execute($data);
    } catch (Exception $e) {
        throw new Exception("Error adding record: " . $e->getMessage());
    }
}

function updateRecord($conn, $table, $data, $id)
{
    try {
        // Determine the correct primary key field
        $primaryKey = match ($table) {
            'orders' => 'order_id',
            'users' => 'user_id',
            default => 'id'
        };

        $sets = [];
        foreach (array_keys($data) as $field) {
            $sets[] = "$field = :$field";
        }

        $sql = "UPDATE $table SET " . implode(", ", $sets) . " WHERE $primaryKey = :id";
        $data['id'] = $id;
        $stmt = $conn->prepare($sql);
        return $stmt->execute($data);
    } catch (Exception $e) {
        throw new Exception("Error updating record: " . $e->getMessage());
    }
}

function deleteRecord($conn, $table, $id)
{
    try {
        $primaryKey = ($table === 'orders') ? 'order_id' : (($table === 'users') ? 'user_id' : 'id');

        $sql = "DELETE FROM $table WHERE $primaryKey = :id";
        $stmt = $conn->prepare($sql);
        return $stmt->execute(['id' => $id]);
    } catch (Exception $e) {
        throw new Exception("Error deleting record: " . $e->getMessage());
    }
}

function searchRecords($conn, $table, $searchTerm)
{
    try {
        $sql = match ($table) {
            'products' => "SELECT * FROM products WHERE name LIKE :search OR description LIKE :search",
            'users' => "SELECT * FROM users WHERE email LIKE :search OR name LIKE :search",
            'orders' => "SELECT o.*, u.email FROM orders o JOIN users u ON o.user_id = u.user_id WHERE o.order_id LIKE :search OR u.email LIKE :search",
            default => throw new Exception("Invalid table specified"),
        };

        $stmt = $conn->prepare($sql);
        $stmt->execute(['search' => "%$searchTerm%"]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        throw new Exception("Error searching records: " . $e->getMessage());
    }
}

// Add this new function after the other CRUD functions
function exportToCSV($conn, $table)
{
    try {
        $stmt = $conn->query("SELECT * FROM $table");
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if (empty($data)) {
            throw new Exception("No data to export");
        }

        // Set headers for CSV download
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $table . '_export_' . date('Y-m-d') . '.csv"');

        // Create output stream
        $output = fopen('php://output', 'w');

        // Add headers
        fputcsv($output, array_keys($data[0]));

        // Add data
        foreach ($data as $row) {
            fputcsv($output, $row);
        }

        fclose($output);
        exit();
    } catch (Exception $e) {
        throw new Exception("Error exporting data: " . $e->getMessage());
    }
}

// Handle CRUD operations
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['action'])) {
            switch ($_POST['action']) {
                case 'add':
                    $data = json_decode($_POST['data'], true);
                    addRecord($conn, $_POST['table'], $data);
                    break;
                case 'update':
                    updateRecord($conn, $_POST['table'], $_POST['data'], $_POST['id']);
                    break;
                case 'delete':
                    deleteRecord($conn, $_POST['table'], $_POST['id']);
                    break;
            }
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Handle search
$searchResults = [];
if (isset($_GET['search'])) {
    try {
        $searchResults = searchRecords($conn, $_GET['table'], $_GET['search']);
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}

// Handle export
if (isset($_GET['export']) && isset($_GET['table'])) {
    try {
        exportToCSV($conn, $_GET['table']);
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Furni</title>
    <!-- Bootstrap CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }

        .sidebar a {
            color: white;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .card-dashboard {
            transition: transform 0.2s;
        }

        .card-dashboard:hover {
            transform: translateY(-5px);
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar p-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Furni Admin</h4>
                </div>
                <div class="list-group">
                    <a href="#" class="list-group-item list-group-item-action active bg-dark">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                    <a href="admin_products.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-box me-2"></i> Products
                    </a>
                    <a href="admin_orders.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-shopping-cart me-2"></i> Orders
                    </a>
                    <a href="admin_users.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-users me-2"></i> Users
                    </a>
                    <a href="admin_newsletter.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-envelope me-2"></i> Newsletter
                    </a>
                    <a href="logout.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>Dashboard</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <select id="exportTable" class="form-select form-select-sm me-2">
                                <option value="products">Products</option>
                                <option value="users">Users</option>
                                <option value="orders">Orders</option>
                            </select>
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="exportTable()">Export</button>
                        </div>
                    </div>
                </div>

                <!-- Statistics Cards -->
                <div class="row mb-4">
                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-primary shadow h-100 py-2 card-dashboard">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Users</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $userCount; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-users fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-success shadow h-100 py-2 card-dashboard">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Orders</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $orderCount; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-shopping-cart fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-info shadow h-100 py-2 card-dashboard">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Products</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $productCount; ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-box fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-3 col-md-6 mb-4">
                        <div class="card border-left-warning shadow h-100 py-2 card-dashboard">
                            <div class="card-body">
                                <div class="row no-gutters align-items-center">
                                    <div class="col mr-2">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Revenue</div>
                                        <div class="h5 mb-0 font-weight-bold text-gray-800">$<?php echo number_format($totalRevenue, 2); ?></div>
                                    </div>
                                    <div class="col-auto">
                                        <i class="fas fa-dollar-sign fa-2x text-gray-300"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Search Records -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3 d-flex justify-content-between align-items-center">
                        <h6 class="m-0 font-weight-bold text-primary">Search Records</h6>
                        <button class="btn btn-primary btn-sm" onclick="addNewRecord()">
                            <i class="fas fa-plus me-1"></i> Add New
                        </button>
                    </div>
                    <div class="card-body">
                        <form method="GET" class="mb-3">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control" placeholder="Search...">
                                <select name="table" class="form-select">
                                    <option value="products">Products</option>
                                    <option value="users">Users</option>
                                    <option value="orders">Orders</option>
                                </select>
                                <button type="submit" class="btn btn-primary">Search</button>
                            </div>
                        </form>

                        <?php if (!empty($searchResults)): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <?php foreach (array_keys($searchResults[0]) as $column): ?>
                                                <th><?php echo htmlspecialchars(ucfirst($column)); ?></th>
                                            <?php endforeach; ?>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($searchResults as $result): ?>
                                            <tr>
                                                <?php foreach ($result as $value): ?>
                                                    <td><?php echo htmlspecialchars($value); ?></td>
                                                <?php endforeach; ?>
                                                <td>
                                                    <?php
                                                    // Determine the correct ID field based on the table
                                                    $idField = $_GET['table'] === 'orders' ? 'order_id' : ($_GET['table'] === 'users' ? 'user_id' : 'id');
                                                    $recordId = isset($result[$idField]) ? $result[$idField] : null;
                                                    if ($recordId !== null): // Only show action buttons if we have a valid ID
                                                    ?>
                                                        <button class="btn btn-sm btn-primary" onclick="editRecord(<?php echo $recordId; ?>)">
                                                            <i class="fas fa-edit"></i>
                                                        </button>
                                                        <button class="btn btn-sm btn-danger" onclick="deleteRecord(<?php echo $recordId; ?>)">
                                                            <i class="fas fa-trash"></i>
                                                        </button>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Recent Orders -->
                <div class="card shadow mb-4">
                    <div class="card-header py-3">
                        <h6 class="m-0 font-weight-bold text-primary">Recent Orders</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered" width="100%" cellspacing="0">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recentOrders as $order): ?>
                                        <tr>
                                            <td>#<?php echo $order['order_id']; ?></td>
                                            <td><?php echo htmlspecialchars($order['email']); ?></td>
                                            <td>$<?php echo number_format($order['total_amount'], 2); ?></td>
                                            <td>
                                                <span class="badge bg-<?php echo $order['order_status'] === 'completed' ? 'success' : 'warning'; ?>">
                                                    <?php echo ucfirst($order['order_status']); ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($order['order_date'])); ?></td>
                                            <td>
                                                <a href="admin_order_detail.php?id=<?php echo $order['order_id']; ?>" class="btn btn-sm btn-primary">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        function editRecord(id) {
            const table = document.querySelector('select[name="table"]').value;
            let fields;

            // Define fields based on table
            switch (table) {
                case 'products':
                    fields = ['name', 'description', 'price', 'stock'];
                    break;
                case 'users':
                    fields = ['email', 'name', 'role'];
                    break;
                case 'orders':
                    fields = ['user_id', 'total_amount', 'order_status'];
                    break;
                default:
                    alert('Please select a valid table');
                    return;
            }

            // Create form data object
            const data = {};
            fields.forEach(field => {
                const value = prompt(`Enter new ${field}:`);
                if (value === null) return; // User clicked cancel
                data[field] = value;
            });

            // Submit form
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" value="${id}">
                <input type="hidden" name="table" value="${table}">
                <input type="hidden" name="data" value='${JSON.stringify(data)}'>
            `;
            document.body.appendChild(form);
            form.submit();
        }

        function deleteRecord(id) {
            if (confirm('Are you sure you want to delete this record?')) {
                const table = document.querySelector('select[name="table"]').value;
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="${id}">
                    <input type="hidden" name="table" value="${table}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        // Add function to handle adding new records
        function addNewRecord() {
            const table = document.querySelector('select[name="table"]').value;
            let fields;

            // Define fields based on table
            switch (table) {
                case 'products':
                    fields = ['name', 'description', 'price', 'stock'];
                    break;
                case 'users':
                    fields = ['email', 'name', 'role'];
                    break;
                case 'orders':
                    fields = ['user_id', 'total_amount', 'order_status'];
                    break;
                default:
                    alert('Please select a valid table');
                    return;
            }

            // Create form data object
            const data = {};
            fields.forEach(field => {
                const value = prompt(`Enter ${field}:`);
                if (value === null) return; // User clicked cancel
                data[field] = value;
            });

            // Submit form
            const form = document.createElement('form');
            form.method = 'POST';
            form.innerHTML = `
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="table" value="${table}">
                <input type="hidden" name="data" value='${JSON.stringify(data)}'>
            `;
            document.body.appendChild(form);
            form.submit();
        }

        function exportTable() {
            const table = document.getElementById('exportTable').value;
            window.location.href = `admin_dashboard.php?export=true&table=${table}`;
        }
    </script>
</body>

</html>