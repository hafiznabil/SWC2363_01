<?php
session_start();
require_once '../config/db_connection.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

try {
    $pdo = getDBConnection();

    // Fetch all orders for the user
    $order_query = "SELECT o.*, 
                    COUNT(oi.order_item_id) as total_items,
                    SUM(oi.quantity) as total_quantity
                    FROM orders o 
                    JOIN order_items oi ON o.order_id = oi.order_id
                    WHERE o.user_id = ?
                    GROUP BY o.order_id
                    ORDER BY o.order_date DESC";

    $stmt = $pdo->prepare($order_query);
    $stmt->execute([$_SESSION['user_id']]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Error: " . $e->getMessage());
    $error_message = "An error occurred while fetching your orders.";
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Untree.co">
    <link rel="shortcut icon" href="../favicon.png">

    <meta name="description" content="" />
    <meta name="keywords" content="bootstrap, bootstrap4" />

    <!-- Bootstrap CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="../css/tiny-slider.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/orders.css" rel="stylesheet">
    <title>My Orders - Furni</title>
</head>

<body>

    <div class="hero">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-lg-5">
                    <div class="intro-excerpt">
                        <h1>My Orders</h1>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="untree_co-section orders-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <!-- Account Navigation -->
                    <div class="card mb-4 account-menu">
                        <div class="card-body">
                            <h5 class="card-title">Account Menu</h5>
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link active" href="orders.php">My Orders</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="profile_settings.php">Profile Settings</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../index.php">Home</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="../logout.php">Logout</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-9">
                    <?php if (isset($error_message)): ?>
                        <div class="alert alert-danger"><?= $error_message ?></div>
                    <?php endif; ?>

                    <?php if (empty($orders)): ?>
                        <div class="card empty-orders">
                            <div class="card-body text-center">
                                <h5>No orders found</h5>
                                <p>You haven't placed any orders yet.</p>
                                <a href="../shop.php" class="btn btn-primary">Start Shopping</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <?php foreach ($orders as $order): ?>
                            <div class="card mb-4 order-card">
                                <div class="card-header">
                                    <div class="row align-items-center">
                                        <div class="col">
                                            <h5 class="mb-0">Order #<?= htmlspecialchars($order['order_id']) ?></h5>
                                        </div>
                                        <div class="col text-end">
                                            <span class="badge bg-<?= $order['status'] === 'completed' ? 'success' : 'primary' ?>">
                                                <?= ucfirst(htmlspecialchars($order['status'])) ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p class="mb-1">Order Date: <?= date('F j, Y', strtotime($order['order_date'])) ?></p>
                                            <p class="mb-1">Total Items: <?= $order['total_quantity'] ?></p>
                                            <p class="mb-1">Total Amount: RM<?= number_format($order['total_amount'], 2) ?></p>
                                        </div>
                                        <div class="col-md-6 text-md-end">
                                            <a href="../thankyou.php?order_id=<?= $order['order_id'] ?>"
                                                class="btn btn-outline-primary btn-sm">View Details</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="../js/bootstrap.bundle.min.js"></script>
    <script src="../js/tiny-slider.js"></script>
    <script src="../js/custom.js"></script>
</body>

</html>