<?php
session_start();
require_once 'config/db_connection.php';  // Ensure this points to the correct path

try {
    $conn = getDBConnection();
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['action'])) {
        header("Location: login.html");
        exit;
    }

    $action = $_POST['action'];

    if ($action === 'signup') {
        // Handle Sign-Up
        $first_name = trim($_POST['first_name']);
        $last_name = trim($_POST['last_name']);
        $email = trim($_POST['email']);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

        try {
            // Check if email already exists
            $checkStmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $checkStmt->execute([$email]);

            if ($checkStmt->rowCount() > 0) {
                $_SESSION['error'] = 'Email already registered.';
                header("Location: login.html");
                exit;
            }

            // Insert new user
            $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, password, role) VALUES (?, ?, ?, ?, 'user')");
            if ($stmt->execute([$first_name, $last_name, $email, $password])) {
                $_SESSION['success'] = 'Registration successful!';
                header("Location: login.html");
                exit;
            } else {
                $_SESSION['error'] = 'Error during registration.';
                header("Location: login.html");
                exit;
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
            header("Location: login.html");
            exit;
        }
    } elseif ($action === 'login') {
        // Handle Login
        $email = trim($_POST['email']);
        $password = $_POST['password'];

        try {
            // Fetch user with the provided email
            $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
            $stmt->execute([$email]);

            if ($stmt->rowCount() === 1) {
                $user = $stmt->fetch();

                // Verify password
                if (password_verify($password, $user['password'])) {
                    session_regenerate_id(true); // Prevent session fixation
                    $_SESSION['user_id'] = $user['user_id'];
                    $_SESSION['role'] = $user['role'];

                    if ($user['role'] === 'admin') {
                        header("Location: admin_dashboard.php");
                    } else {
                        header("Location: index.php");
                    }
                    exit;
                } else {
                    $_SESSION['error'] = 'Invalid password.';
                    header("Location: login.html");
                    exit;
                }
            } else {
                $_SESSION['error'] = 'Invalid email.';
                header("Location: login.html");
                exit;
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
            header("Location: login.html");
            exit;
        }
    }
} else {
    // Redirect to login page if accessed without POST request
    header("Location: login.html");
    exit;
}
