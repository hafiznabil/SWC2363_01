<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">

	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap4" />

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
	<link href="css/tiny-slider.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<title>Furni</title>
</head>

<body>

	<!-- Start Header/Navigation -->
	<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

		<div class="container">
			<a class="navbar-brand" href="index.php">Furni<span>.</span></a>

			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarsFurni">
				<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
					<li class="nav-item ">
						<a class="nav-link" href="index.php">Home</a>
					</li>
					<li class="active"><a class="nav-link" href="shop.php">Shop</a></li>
					<li><a class="nav-link" href="about.php">About us</a></li>
					<li><a class="nav-link" href="services.php">Services</a></li>
					<li><a class="nav-link" href="blog.php">Blog</a></li>
					<li><a class="nav-link" href="contact.php">Contact us</a></li>
				</ul>

				<ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
							<img src="images/user.svg" alt="User">
						</a>
						<?php if (isset($_SESSION['user_id'])): ?>
							<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
								<li><a class="dropdown-item" href="account/profile_settings.php">Profile Settings</a></li>
								<li><a class="dropdown-item" href="account/orders.php">My Orders</a></li>
								<li>
									<hr class="dropdown-divider">
								</li>
								<li><a class="dropdown-item" href="logout.php">Logout</a></li>
							</ul>
						<?php else: ?>
							<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
								<li><a class="dropdown-item" href="account/profile_settings.php">Profile Settings</a></li>
								<li><a class="dropdown-item" href="account/orders.php">My Orders</a></li>
								<li><a class="dropdown-item" href="logout.php">Logout</a></li>
							</ul>
						<?php endif; ?>
					</li>
					<li><a class="nav-link" href="cart.php"><img src="images/cart.svg"></a></li>
				</ul>
			</div>
		</div>

	</nav>
	<!-- End Header/Navigation -->

	<!-- Start Hero Section -->
	<div class="hero">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-5">
					<div class="intro-excerpt">
						<h1>Shop</h1>
					</div>
				</div>
				<div class="col-lg-7">

				</div>
			</div>
		</div>
	</div>
	<!-- End Hero Section -->



	<div class="untree_co-section product-section before-footer-section">
		<div class="container">
			<div class="row">

				<!-- Start Column 1 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5">
					<div class="product-item">
						<img src="images/product-3.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Nordic Chair</h3>
						<strong class="product-price">RM 50.00</strong>

						<form action="cart.php" method="POST" class="add-to-cart-form">
							<input type="hidden" name="product_id" value="1">
							<input type="hidden" name="product_name" value="Nordic Chair">
							<input type="hidden" name="product_price" value="50.00">
							<input type="number" name="quantity" value="1" min="1" max="10" class="form-control mb-2">
							<button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">Add to Cart</button>
						</form>
					</div>
				</div>
				<!-- End Column 1 -->

				<!-- Start Column 2 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5">
					<div class="product-item">
						<img src="images/product-1.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Nordic Chair</h3>
						<strong class="product-price">RM 50.00</strong>

						<form action="cart.php" method="POST" class="add-to-cart-form">
							<input type="hidden" name="product_id" value="2">
							<input type="hidden" name="product_name" value="Nordic Chair">
							<input type="hidden" name="product_price" value="50.00">
							<input type="number" name="quantity" value="1" min="1" max="10" class="form-control mb-2">
							<button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">Add to Cart</button>
						</form>
					</div>
				</div>
				<!-- End Column 2 -->

				<!-- Start Column 3 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5">
					<div class="product-item">
						<img src="images/product-2.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Kruzo Aero Chair</h3>
						<strong class="product-price">RM 78.00</strong>

						<form action="cart.php" method="POST" class="add-to-cart-form">
							<input type="hidden" name="product_id" value="3">
							<input type="hidden" name="product_name" value="Kruzo Aero Chair">
							<input type="hidden" name="product_price" value="78.00">
							<input type="number" name="quantity" value="1" min="1" max="10" class="form-control mb-2">
							<button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">Add to Cart</button>
						</form>
					</div>
				</div>
				<!-- End Column 3 -->

				<!-- Start Column 4 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5">
					<div class="product-item">
						<img src="images/product-3.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Ergonomic Chair</h3>
						<strong class="product-price">RM 43.00</strong>

						<form action="cart.php" method="POST" class="add-to-cart-form">
							<input type="hidden" name="product_id" value="4">
							<input type="hidden" name="product_name" value="Ergonomic Chair">
							<input type="hidden" name="product_price" value="43.00">
							<input type="number" name="quantity" value="1" min="1" max="10" class="form-control mb-2">
							<button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">Add to Cart</button>
						</form>
					</div>
				</div>
				<!-- End Column 4 -->

				<!-- Start Column 5 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5">
					<div class="product-item">
						<img src="images/product-3.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Nordic Chair</h3>
						<strong class="product-price">RM 50.00</strong>

						<form action="cart.php" method="POST" class="add-to-cart-form">
							<input type="hidden" name="product_id" value="5">
							<input type="hidden" name="product_name" value="Nordic Chair">
							<input type="hidden" name="product_price" value="50.00">
							<input type="number" name="quantity" value="1" min="1" max="10" class="form-control mb-2">
							<button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">Add to Cart</button>
						</form>
					</div>
				</div>
				<!-- End Column 5 -->

				<!-- Start Column 6 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5">
					<div class="product-item">
						<img src="images/product-1.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Nordic Chair</h3>
						<strong class="product-price">RM 50.00</strong>

						<form action="cart.php" method="POST" class="add-to-cart-form">
							<input type="hidden" name="product_id" value="6">
							<input type="hidden" name="product_name" value="Nordic Chair">
							<input type="hidden" name="product_price" value="50.00">
							<input type="number" name="quantity" value="1" min="1" max="10" class="form-control mb-2">
							<button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">Add to Cart</button>
						</form>
					</div>
				</div>
				<!-- End Column 6 -->

				<!-- Start Column 7 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5">
					<div class="product-item">
						<img src="images/product-2.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Kruzo Aero Chair</h3>
						<strong class="product-price">RM 78.00</strong>

						<form action="cart.php" method="POST" class="add-to-cart-form">
							<input type="hidden" name="product_id" value="7">
							<input type="hidden" name="product_name" value="Kruzo Aero Chair">
							<input type="hidden" name="product_price" value="78.00">
							<input type="number" name="quantity" value="1" min="1" max="10" class="form-control mb-2">
							<button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">Add to Cart</button>
						</form>
					</div>
				</div>
				<!-- End Column 7 -->

				<!-- Start Column 8 -->
				<div class="col-12 col-md-4 col-lg-3 mb-5">
					<div class="product-item">
						<img src="images/product-3.png" class="img-fluid product-thumbnail">
						<h3 class="product-title">Ergonomic Chair</h3>
						<strong class="product-price">RM 43.00</strong>

						<form action="cart.php" method="POST" class="add-to-cart-form">
							<input type="hidden" name="product_id" value="8">
							<input type="hidden" name="product_name" value="Ergonomic Chair">
							<input type="hidden" name="product_price" value="43.00">
							<input type="number" name="quantity" value="1" min="1" max="10" class="form-control mb-2">
							<button type="submit" name="add_to_cart" class="btn btn-primary btn-sm">Add to Cart</button>
						</form>
					</div>
				</div>
				<!-- End Column 8 -->

			</div>
		</div>
	</div>


	<!-- Start Footer Section -->
	<footer class="footer-section">
		<div class="container relative">

			<div class="sofa-img">
				<img src="images/sofa.png" alt="Image" class="img-fluid">
			</div>

			<div class="row">
				<div class="col-lg-8">
					<div class="subscription-form">
						<h3 class="d-flex align-items-center">
							<span class="me-1"><img src="./images/envelope-outline.svg" alt="Image" class="img-fluid"></span>
							<span>Subscribe to Newsletter</span>
						</h3>

						<?php
						if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['subscribe'])) {
							// Database connection
							$conn = new mysqli("localhost", "root", "", "furni_store");

							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							}

							// Get and sanitize input
							$name = $conn->real_escape_string($_POST['subscriber_name']);
							$email = $conn->real_escape_string($_POST['subscriber_email']);

							// Check if email already exists
							$checkEmail = $conn->query("SELECT email FROM newsletter_subscribers WHERE email = '$email'");

							if ($checkEmail->num_rows > 0) {
								echo '<div class="alert alert-warning alert-dismissible fade show" role="alert" id="subscribeAlert">
										This email is already subscribed!
										<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
									  </div>';
							} else {
								// Insert new subscriber
								$sql = "INSERT INTO newsletter_subscribers (name, email) VALUES ('$name', '$email')";

								if ($conn->query($sql) === TRUE) {
									echo '<div class="alert alert-success alert-dismissible fade show" role="alert" id="subscribeAlert">
											Thank you for subscribing!
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
										  </div>';
								} else {
									echo '<div class="alert alert-danger alert-dismissible fade show" role="alert" id="subscribeAlert">
											Error: ' . $conn->error . '
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
										  </div>';
								}
							}



							$conn->close();
						}
						?>

						<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="row g-3">
							<div class="col-auto">
								<input type="text" name="subscriber_name" class="form-control" placeholder="Enter your name" required>
							</div>
							<div class="col-auto">
								<input type="email" name="subscriber_email" class="form-control" placeholder="Enter your email" required>
							</div>
							<div class="col-auto">
								<button type="submit" name="subscribe" class="btn btn-primary">
									<span class="fa fa-paper-plane"></span>
								</button>
							</div>
						</form>

					</div>
				</div>
			</div>

			<div class="row g-5 mb-5">
				<div class="col-lg-4">
					<div class="mb-4 footer-logo-wrap"><a href="#" class="footer-logo">Furni<span>.</span></a></div>
					<p class="mb-4">Furni offers a curated collection of modern, stylish furniture designed to enhance your home. Our high-quality pieces combine comfort and aesthetics, crafted from sustainable materials for durability and eco-friendliness. Transform your living space with Furni’s innovative designs that reflect your unique style.</p>

					<ul class="list-unstyled custom-social">
						<li><a href="#"><span class="fa fa-brands fa-facebook-f"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-twitter"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-instagram"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-linkedin"></span></a></li>
					</ul>
				</div>

				<div class="col-lg-8">
					<div class="row links-wrap">
						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">About us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Blog</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">Support</a></li>
								<li><a href="#">Knowledge base</a></li>
								<li><a href="#">Live chat</a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>
					</div>
				</div>

			</div>

			<div class="border-top copyright">
				<div class="row pt-4">
					<div class="col-lg-6">
						<p class="mb-2 text-center text-lg-start">Furni &copy;<script>
								document.write(new Date().getFullYear());
							</script>. All Rights Reserved. &mdash; Designed with love by <a href="#">NABIL </a>
						</p>
					</div>

					<div class="col-lg-6 text-center text-lg-end">
						<ul class="list-unstyled d-inline-flex ms-auto">
							<li class="me-4"><a href="#">Terms &amp; Conditions</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>
					</div>

				</div>
			</div>

		</div>
	</footer>
	<!-- End Footer Section -->


	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/tiny-slider.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>