<?php
session_start();

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
	$_SESSION['cart'] = [];
}

function connectDatabase()
{
	try {
		$conn = new mysqli("localhost", "root", "", "furni_store");
		if ($conn->connect_error) {
			throw new Exception("Connection failed: " . $conn->connect_error);
		}
		return $conn;
	} catch (Exception $e) {
		error_log("Database Connection Error: " . $e->getMessage());
		die("Unable to connect to database. Please try again later.");
	}
}

function addToCart($product_id, $product_name, $product_price, $quantity)
{
	try {
		$conn = connectDatabase();

		// Validate inputs
		$product_id = filter_var($product_id, FILTER_VALIDATE_INT);
		$quantity = filter_var($quantity, FILTER_VALIDATE_INT);
		if (!$product_id || !$quantity || $quantity < 1) {
			throw new Exception("Invalid product or quantity");
		}

		// Check if product exists and has enough stock
		$stmt = $conn->prepare("SELECT stock FROM products WHERE product_id = ?");
		$stmt->bind_param("i", $product_id);
		$stmt->execute();
		$result = $stmt->get_result();

		if ($result->num_rows > 0) {
			$product = $result->fetch_assoc();

			// Check current cart quantity + new quantity against stock
			$current_quantity = isset($_SESSION['cart'][$product_id]) ?
				$_SESSION['cart'][$product_id]['quantity'] : 0;
			$total_quantity = $current_quantity + $quantity;

			if ($product['stock'] >= $total_quantity) {
				addToCartTable($conn, $product_id, $quantity);
				addToSessionCart($product_id, $product_name, $product_price, $quantity);
				echo "<div class='alert alert-success'>Product added to cart successfully!</div>";
			} else {
				echo "<div class='alert alert-danger'>Not enough stock available! Only {$product['stock']} items remaining.</div>";
			}
		} else {
			echo "<div class='alert alert-danger'>Product not found!</div>";
		}
		$conn->close();
	} catch (Exception $e) {
		error_log("Add to Cart Error: " . $e->getMessage());
		echo "<div class='alert alert-danger'>Unable to add product to cart. Please try again.</div>";
	}
}

function addToCartTable($conn, $product_id, $quantity)
{
	if (isset($_SESSION['user_id'])) {
		$user_id = $_SESSION['user_id'];
		$stmt = $conn->prepare("INSERT INTO cart (user_id, product_id, quantity, added_at) 
							  VALUES (?, ?, ?, NOW()) 
							  ON DUPLICATE KEY UPDATE quantity = quantity + ?");
		$stmt->bind_param("iiii", $user_id, $product_id, $quantity, $quantity);
		$stmt->execute();
	}
}

function addToSessionCart($product_id, $product_name, $product_price, $quantity)
{
	if (!isset($_SESSION['cart'][$product_id])) {
		$_SESSION['cart'][$product_id] = [
			'name' => $product_name,
			'price' => $product_price,
			'quantity' => $quantity
		];
	} else {
		$_SESSION['cart'][$product_id]['quantity'] += $quantity;
	}
}

function updateCart($quantities)
{
	try {
		if (!is_array($quantities)) {
			throw new Exception("Invalid update request");
		}

		$conn = connectDatabase();
		$updates_successful = true;

		foreach ($quantities as $product_id => $quantity) {
			// Validate inputs
			$product_id = filter_var($product_id, FILTER_VALIDATE_INT);
			$quantity = filter_var($quantity, FILTER_VALIDATE_INT);

			if (!$product_id || $quantity === false) {
				continue;
			}

			// Check stock availability
			$stmt = $conn->prepare("SELECT stock FROM products WHERE product_id = ?");
			$stmt->bind_param("i", $product_id);
			$stmt->execute();
			$result = $stmt->get_result();
			$product = $result->fetch_assoc();

			if ($quantity > 0 && $quantity <= $product['stock']) {
				if (isset($_SESSION['cart'][$product_id])) {
					$_SESSION['cart'][$product_id]['quantity'] = $quantity;

					if (isset($_SESSION['user_id'])) {
						$user_id = $_SESSION['user_id'];
						$stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE user_id = ? AND product_id = ?");
						$stmt->bind_param("iii", $quantity, $user_id, $product_id);
						if (!$stmt->execute()) {
							$updates_successful = false;
						}
					}
				}
			} elseif ($quantity <= 0) {
				// Remove item if quantity is 0 or negative
				removeFromCart($product_id);
			} else {
				echo "<div class='alert alert-warning'>Quantity for " .
					htmlspecialchars($_SESSION['cart'][$product_id]['name']) .
					" exceeds available stock ({$product['stock']} available)</div>";
				$updates_successful = false;
			}
		}

		$conn->close();

		if ($updates_successful) {
			echo "<div class='alert alert-success'>Cart updated successfully!</div>";
		}
	} catch (Exception $e) {
		error_log("Update Cart Error: " . $e->getMessage());
		echo "<div class='alert alert-danger'>Unable to update cart. Please try again.</div>";
	}
}

function removeFromCart($product_id)
{
	try {
		$product_id = filter_var($product_id, FILTER_VALIDATE_INT);
		if (!$product_id) {
			throw new Exception("Invalid product ID");
		}

		if (isset($_SESSION['cart'][$product_id])) {
			// Remove from database if user is logged in
			if (isset($_SESSION['user_id'])) {
				$conn = connectDatabase();
				$stmt = $conn->prepare("DELETE FROM cart WHERE user_id = ? AND product_id = ?");
				$stmt->bind_param("ii", $_SESSION['user_id'], $product_id);
				$stmt->execute();
				$conn->close();
			}

			// Remove from session
			unset($_SESSION['cart'][$product_id]);
			echo "<div class='alert alert-success'>Item removed from cart!</div>";
		}
	} catch (Exception $e) {
		error_log("Remove from Cart Error: " . $e->getMessage());
		echo "<div class='alert alert-danger'>Unable to remove item. Please try again.</div>";
	}
}

// Process form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	if (isset($_POST['add_to_cart'])) {
		// Validate and sanitize inputs
		$product_id = filter_input(INPUT_POST, 'product_id', FILTER_VALIDATE_INT);
		$product_name = filter_input(INPUT_POST, 'product_name', FILTER_SANITIZE_STRING);
		$product_price = filter_input(INPUT_POST, 'product_price', FILTER_VALIDATE_FLOAT);
		$quantity = filter_input(INPUT_POST, 'quantity', FILTER_VALIDATE_INT);

		if ($product_id && $product_name && $product_price && $quantity) {
			addToCart($product_id, $product_name, $product_price, $quantity);
		} else {
			echo "<div class='alert alert-danger'>Invalid product information</div>";
		}
	} elseif (isset($_POST['update_cart'])) {
		if (isset($_POST['quantities']) && is_array($_POST['quantities'])) {
			updateCart($_POST['quantities']);
		} else {
			echo "<div class='alert alert-danger'>No items to update</div>";
		}
	}
}

// Handle remove item request
if (isset($_GET['remove'])) {
	$product_id = filter_input(INPUT_GET, 'remove', FILTER_VALIDATE_INT);
	if ($product_id) {
		removeFromCart($product_id);
	}
}
?>

<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">

	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap4" />

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
	<link href="css/tiny-slider.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<title>Furni</title>
</head>

<body>

	<!-- Start Header/Navigation -->
	<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

		<div class="container">
			<a class="navbar-brand" href="index.php">Furni<span>.</span></a>

			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarsFurni">
				<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
					<li class="nav-item ">
						<a class="nav-link" href="index.php">Home</a>
					</li>
					<li><a class="nav-link" href="shop.php">Shop</a></li>
					<li><a class="nav-link" href="about.php">About us</a></li>
					<li><a class="nav-link" href="services.php">Services</a></li>
					<li><a class="nav-link" href="blog.php">Blog</a></li>
					<li><a class="nav-link" href="contact.php">Contact us</a></li>
				</ul>

				<ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
					<li><a class="nav-link" href="cart.php"><img src="images/cart.svg"></a></li>
				</ul>
			</div>
		</div>

	</nav>
	<!-- End Header/Navigation -->

	<!-- Start Hero Section -->
	<div class="hero">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-5">
					<div class="intro-excerpt">
						<h1>Cart</h1>
					</div>
				</div>
				<div class="col-lg-7">

				</div>
			</div>
		</div>
	</div>
	<!-- End Hero Section -->



	<div class="untree_co-section before-footer-section">
		<div class="container">
			<div class="row mb-5">
				<form class="col-md-12" method="post">
					<div class="site-blocks-table">
						<table class="table">
							<thead>
								<tr>
									<th class="product-thumbnail">Image</th>
									<th class="product-name">Product</th>
									<th class="product-price">Price</th>
									<th class="product-quantity">Quantity</th>
									<th class="product-total">Total</th>
									<th class="product-remove">Remove</th>
								</tr>
							</thead>
							<tbody>
								<?php
								$total = 0;
								if (empty($_SESSION['cart'])) {
									echo '<tr><td colspan="6" class="text-center">Your cart is empty</td></tr>';
								} else {
									foreach ($_SESSION['cart'] as $product_id => $item):
										$subtotal = $item['price'] * $item['quantity'];
										$total += $subtotal;
								?>
										<tr>
											<td class="product-thumbnail">
												<img src="images/product-<?php echo $product_id; ?>.png" alt="Image" class="img-fluid">
											</td>
											<td class="product-name">
												<h2 class="h5 text-black"><?php echo htmlspecialchars($item['name']); ?></h2>
											</td>
											<td>RM <?php echo number_format($item['price'], 2); ?></td>
											<td>
												<div class="input-group mb-3 d-flex align-items-center quantity-container" style="max-width: 120px;">
													<input type="number" name="quantities[<?php echo $product_id; ?>]"
														class="form-control text-center quantity-amount"
														value="<?php echo $item['quantity']; ?>" min="1">
												</div>
											</td>
											<td>RM <?php echo number_format($subtotal, 2); ?></td>
											<td><a href="?remove=<?php echo $product_id; ?>" class="btn btn-black btn-sm">X</a></td>
										</tr>
								<?php
									endforeach;
								}
								?>
							</tbody>
						</table>
					</div>

					<div class="row mb-5">
						<div class="col-md-6">
							<input type="submit" class="btn btn-black btn-sm btn-block" name="update_cart" value="Update Cart">
						</div>
					</div>
				</form>
			</div>

			<div class="row justify-content-end">
				<div class="col-md-7">
					<div class="row">
						<div class="col-md-12 text-right border-bottom mb-5">
							<h3 class="text-black h4 text-uppercase">Cart Totals</h3>
						</div>
					</div>
					<div class="row mb-5">
						<div class="col-md-6">
							<span class="text-black">Total</span>
						</div>
						<div class="col-md-6 text-right">
							<strong class="text-black">RM <?php echo number_format($total, 2); ?></strong>
						</div>
					</div>

					<div class="row">
						<div class="col-md-12">
							<button class="btn btn-black btn-lg py-3 btn-block" onclick="window.location='checkout.php'">Proceed To Checkout</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


	<!-- Start Footer Section -->
	<footer class="footer-section">
		<div class="container relative">

			<div class="sofa-img">
				<img src="images/sofa.png" alt="Image" class="img-fluid">
			</div>

			<div class="row">
				<div class="col-lg-8">
					<div class="subscription-form">
						<h3 class="d-flex align-items-center"><span class="me-1"><img src="images/envelope-outline.svg" alt="Image" class="img-fluid"></span><span>Subscribe to Newsletter</span></h3>

						<form action="#" class="row g-3">
							<div class="col-auto">
								<input type="text" class="form-control" placeholder="Enter your name">
							</div>
							<div class="col-auto">
								<input type="email" class="form-control" placeholder="Enter your email">
							</div>
							<div class="col-auto">
								<button class="btn btn-primary">
									<span class="fa fa-paper-plane"></span>
								</button>
							</div>
						</form>

					</div>
				</div>
			</div>

			<div class="row g-5 mb-5">
				<div class="col-lg-4">
					<div class="mb-4 footer-logo-wrap"><a href="#" class="footer-logo">Furni<span>.</span></a></div>
					<p class="mb-4">Furni offers a curated collection of modern, stylish furniture designed to enhance your home. Our high-quality pieces combine comfort and aesthetics, crafted from sustainable materials for durability and eco-friendliness. Transform your living space with Furni’s innovative designs that reflect your unique style.</p>

					<ul class="list-unstyled custom-social">
						<li><a href="#"><span class="fa fa-brands fa-facebook-f"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-twitter"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-instagram"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-linkedin"></span></a></li>
					</ul>
				</div>

				<div class="col-lg-8">
					<div class="row links-wrap">
						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">About us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Blog</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">Support</a></li>
								<li><a href="#">Knowledge base</a></li>
								<li><a href="#">Live chat</a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>
					</div>
				</div>

			</div>

			<div class="border-top copyright">
				<div class="row pt-4">
					<div class="col-lg-6">
						<p class="mb-2 text-center text-lg-start">Furni &copy;<script>
								document.write(new Date().getFullYear());
							</script>. All Rights Reserved. &mdash; Designed with love by <a href="#">NABIL</a>
						</p>
					</div>

					<div class="col-lg-6 text-center text-lg-end">
						<ul class="list-unstyled d-inline-flex ms-auto">
							<li class="me-4"><a href="#">Terms &amp; Conditions</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>
					</div>

				</div>
			</div>

		</div>
	</footer>
	<!-- End Footer Section -->


	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/tiny-slider.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>