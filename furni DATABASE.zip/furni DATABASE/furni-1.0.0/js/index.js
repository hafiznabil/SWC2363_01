document.addEventListener("DOMContentLoaded", function () {
 const autoDismissAlerts = () => {
  const alerts = document.querySelectorAll(".alert");
  alerts.forEach((alert) => {
   // Add initial styles for smooth transition
   alert.style.transition = "all 0.5s ease-in-out";
   alert.style.opacity = "1";

   setTimeout(() => {
    // Use Bootstrap's alert if available, otherwise fallback to vanilla JS
    if (typeof bootstrap !== "undefined") {
     const bsAlert = new bootstrap.Alert(alert);
     bsAlert.close();
    } else {
     alert.style.opacity = "0";
     alert.style.transform = "translateY(-10px)";
     setTimeout(() => alert.remove(), 500);
    }
   }, 3000);
  });
 };

 // Call immediately for any existing alerts
 autoDismissAlerts();

 // Set up a MutationObserver to handle dynamically added alerts
 const observer = new MutationObserver((mutations) => {
  mutations.forEach((mutation) => {
   if (mutation.addedNodes.length) {
    mutation.addedNodes.forEach((node) => {
     if (node.classList && node.classList.contains("alert")) {
      // Apply the same dismissal logic to new alerts
      node.style.transition = "all 0.5s ease-in-out";
      node.style.opacity = "1";

      setTimeout(() => {
       if (typeof bootstrap !== "undefined") {
        const bsAlert = new bootstrap.Alert(node);
        bsAlert.close();
       } else {
        node.style.opacity = "0";
        node.style.transform = "translateY(-10px)";
        setTimeout(() => node.remove(), 500);
       }
      }, 3000);
     }
    });
   }
  });
 });

 // Observe the document for changes
 observer.observe(document, { childList: true, subtree: true });
});
