<?php
// db_connection.php - Database Connection

function getDBConnection()
{
    $host = 'localhost';       // Update with your database host
    $dbname = 'furni_store';    // Update with your database name
    $username = 'root';         // Update with your database username
    $password = '';             // Update with your database password

    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $conn;
    } catch (PDOException $e) {
        throw new Exception("Database connection error: " . $e->getMessage());
    }
}
