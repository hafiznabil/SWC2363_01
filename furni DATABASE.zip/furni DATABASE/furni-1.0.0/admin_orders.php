<?php
session_start();

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: login.html");
    exit;
}

require_once 'config/db_connection.php';

try {
    $conn = getDBConnection();

    // Fetch all orders with user information and order items
    $orders = $conn->query("
        SELECT o.*, u.email, u.first_name, u.last_name, GROUP_CONCAT(oi.product_id, ',') AS product_ids
        FROM orders o
        JOIN users u ON o.user_id = u.user_id
        LEFT JOIN order_items oi ON o.order_id = oi.order_id
        GROUP BY o.order_id
        ORDER BY o.order_date DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}

// Handle order status updates
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    try {
        switch ($_POST['action']) {
            case 'update_status':
                // Convert status to proper case to match enum
                $status = ucfirst(strtolower($_POST['status']));
                $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
                $stmt->execute([$status, $_POST['order_id']]);
                header("Location: admin_orders.php");
                break;
        }
    } catch (Exception $e) {
        $error = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders Management - Furni Admin</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        .sidebar {
            min-height: 100vh;
            background-color: #343a40;
        }

        .sidebar a {
            color: white;
        }

        .sidebar a:hover {
            background-color: #495057;
        }

        .status-pending {
            background-color: #ffc107;
        }

        .status-processing {
            background-color: #17a2b8;
        }

        .status-completed {
            background-color: #28a745;
        }

        .status-cancelled {
            background-color: #dc3545;
        }
    </style>
</head>

<body>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 d-none d-md-block sidebar p-3">
                <div class="text-center mb-4">
                    <h4 class="text-white">Furni Admin</h4>
                </div>
                <div class="list-group">
                    <a href="admin_dashboard.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-tachometer-alt me-2"></i> Dashboard
                    </a>
                    <a href="admin_products.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-box me-2"></i> Products
                    </a>
                    <a href="admin_orders.php" class="list-group-item list-group-item-action active bg-dark">
                        <i class="fas fa-shopping-cart me-2"></i> Orders
                    </a>
                    <a href="admin_users.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-users me-2"></i> Users
                    </a>
                    <a href="admin_newsletter.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-envelope me-2"></i> Newsletter
                    </a>
                    <a href="logout.php" class="list-group-item list-group-item-action bg-dark">
                        <i class="fas fa-sign-out-alt me-2"></i> Logout
                    </a>
                </div>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 ms-sm-auto px-4">
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                    <h1>Orders Management</h1>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <div class="btn-group me-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" onclick="exportOrders()">
                                <i class="fas fa-download"></i> Export
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Orders Table -->
                <div class="card shadow mb-4">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($orders as $order): ?>
                                        <tr>
                                            <td>#<?php echo $order['order_id']; ?></td>
                                            <td>
                                                <?php echo htmlspecialchars($order['first_name'] . ' ' . $order['last_name']); ?>
                                                <br>
                                                <small class="text-muted"><?php echo htmlspecialchars($order['email']); ?></small>
                                            </td>
                                            <td>$<?php echo number_format($order['total_amount'], 2); ?></td>
                                            <td>
                                                <select class="form-select form-select-sm"
                                                    onchange="updateOrderStatus(<?php echo $order['order_id']; ?>, this.value)">
                                                    <option value="Pending" <?php echo $order['status'] === 'Pending' ? 'selected' : ''; ?>>
                                                        Pending
                                                    </option>
                                                    <option value="Completed" <?php echo $order['status'] === 'Completed' ? 'selected' : ''; ?>>
                                                        Completed
                                                    </option>
                                                    <option value="Cancelled" <?php echo $order['status'] === 'Cancelled' ? 'selected' : ''; ?>>
                                                        Cancelled
                                                    </option>
                                                </select>
                                            </td>
                                            <td><?php echo date('Y-m-d H:i', strtotime($order['order_date'])); ?></td>
                                            <td>
                                                <button class="btn btn-sm btn-primary" onclick="viewOrderDetails(<?php echo $order['order_id']; ?>)">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-sm btn-info" onclick="printOrder(<?php echo $order['order_id']; ?>)">
                                                    <i class="fas fa-print"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
    <script>
        function updateOrderStatus(orderId, status) {
            if (confirm('Are you sure you want to update this order\'s status?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="order_id" value="${orderId}">
                    <input type="hidden" name="status" value="${status}">
                `;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function viewOrderDetails(orderId) {
            window.location.href = `admin_order_detail.php?id=${orderId}`;
        }

        function printOrder(orderId) {
            window.open(`admin_order_print.php?id=${orderId}`, '_blank');
        }

        function exportOrders() {
            window.location.href = 'admin_orders_export.php';
        }
    </script>

</body>

</html>