<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="author" content="Untree.co">
	<link rel="shortcut icon" href="favicon.png">

	<meta name="description" content="" />
	<meta name="keywords" content="bootstrap, bootstrap4" />

	<!-- Bootstrap CSS -->
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
	<link href="css/tiny-slider.css" rel="stylesheet">
	<link href="css/style.css" rel="stylesheet">
	<title>Furni </title>
</head>

<body>

	<!-- Start Header/Navigation -->
	<nav class="custom-navbar navbar navbar navbar-expand-md navbar-dark bg-dark" arial-label="Furni navigation bar">

		<div class="container">
			<a class="navbar-brand" href="index.php">Furni<span>.</span></a>

			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarsFurni" aria-controls="navbarsFurni" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarsFurni">
				<ul class="custom-navbar-nav navbar-nav ms-auto mb-2 mb-md-0">
					<li class="nav-item">
						<a class="nav-link" href="index.php">Home</a>
					</li>
					<li><a class="nav-link" href="shop.php">Shop</a></li>
					<li><a class="nav-link" href="about.php">About us</a></li>
					<li><a class="nav-link" href="services.php">Services</a></li>
					<li><a class="nav-link" href="blog.php">Blog</a></li>
					<li class="active"><a class="nav-link" href="contact.php">Contact us</a></li>
				</ul>

				<ul class="custom-navbar-cta navbar-nav mb-2 mb-md-0 ms-5">
					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
							<img src="images/user.svg" alt="User">
						</a>
						<?php if (isset($_SESSION['user_id'])): ?>
							<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
								<li><a class="dropdown-item" href="account/profile_settings.php">Profile Settings</a></li>
								<li><a class="dropdown-item" href="account/orders.php">My Orders</a></li>
								<li>
									<hr class="dropdown-divider">
								</li>
								<li><a class="dropdown-item" href="logout.php">Logout</a></li>
							</ul>
						<?php else: ?>
							<ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
								<li><a class="dropdown-item" href="account/profile_settings.php">Profile Settings</a></li>
								<li><a class="dropdown-item" href="account/orders.php">My Orders</a></li>
								<li><a class="dropdown-item" href="logout.php">Logout</a></li>
							</ul>
						<?php endif; ?>
					</li>
					<li><a class="nav-link" href="cart.php"><img src="images/cart.svg"></a></li>
				</ul>
			</div>
		</div>

	</nav>
	<!-- End Header/Navigation -->

	<!-- Start Hero Section -->
	<div class="hero">
		<div class="container">
			<div class="row justify-content-between">
				<div class="col-lg-5">
					<div class="intro-excerpt">
						<h1>Contact</h1>
						<p class="mb-4">We're here to help! For any questions, assistance with your order, or design advice, feel free to reach out. Our team is ready to support you in creating the perfect space. Contact us via email, phone, or through our social media channels, and we’ll get back to you as soon as possible. We look forward to hearing from you!</p>
						<p><a href="" class="btn btn-secondary me-2">Shop Now</a><a href="#" class="btn btn-white-outline">Explore</a></p>
					</div>
				</div>
				<div class="col-lg-7">
					<div class="hero-img-wrap">
						<img src="images/couch.png" class="img-fluid">
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End Hero Section -->


	<!-- Start Contact Form -->
	<div class="untree_co-section">
		<div class="container">

			<div class="block">
				<div class="row justify-content-center">


					<div class="col-md-8 col-lg-8 pb-4">


						<div class="row mb-5">
							<div class="col-lg-4">
								<div class="service no-shadow align-items-center link horizontal d-flex active" data-aos="fade-left" data-aos-delay="0">
									<div class="service-icon color-1 mb-4">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-geo-alt-fill" viewBox="0 0 16 16">
											<path d="M8 16s6-5.686 6-10A6 6 0 0 0 2 6c0 4.314 6 10 6 10zm0-7a3 3 0 1 1 0-6 3 3 0 0 1 0 6z" />
										</svg>
									</div> <!-- /.icon -->
									<div class="service-contents">
										<p>Furni Showroom
											123 Jalan Ampang,
											50450 Kuala Lumpur,
											Malaysia</p>
									</div> <!-- /.service-contents-->
								</div> <!-- /.service -->
							</div>

							<div class="col-lg-4">
								<div class="service no-shadow align-items-center link horizontal d-flex active" data-aos="fade-left" data-aos-delay="0">
									<div class="service-icon color-1 mb-4">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-envelope-fill" viewBox="0 0 16 16">
											<path d="M.05 3.555A2 2 0 0 1 2 2h12a2 2 0 0 1 1.95 1.555L8 8.414.05 3.555zM0 4.697v7.104l5.803-3.558L0 4.697zM6.761 8.83l-6.57 4.027A2 2 0 0 0 2 14h12a2 2 0 0 0 1.808-1.144l-6.57-4.027L8 9.586l-1.239-.757zm3.436-.586L16 11.801V4.697l-5.803 3.546z" />
										</svg>
									</div> <!-- /.icon -->
									<div class="service-contents">
										<p>furnimalaysia@gmail.com</p>
									</div> <!-- /.service-contents-->
								</div> <!-- /.service -->
							</div>

							<div class="col-lg-4">
								<div class="service no-shadow align-items-center link horizontal d-flex active" data-aos="fade-left" data-aos-delay="0">
									<div class="service-icon color-1 mb-4">
										<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-telephone-fill" viewBox="0 0 16 16">
											<path fill-rule="evenodd" d="M1.885.511a1.745 1.745 0 0 1 2.61.163L6.29 2.98c.329.423.445.974.315 1.494l-.547 2.19a.678.678 0 0 0 .178.643l2.457 2.457a.678.678 0 0 0 .644.178l2.189-.547a1.745 1.745 0 0 1 1.494.315l2.306 1.794c.829.645.905 1.87.163 2.611l-1.034 1.034c-.74.74-1.846 1.065-2.877.702a18.634 18.634 0 0 1-7.01-4.42 18.634 18.634 0 0 1-4.42-7.009c-.362-1.03-.037-2.137.703-2.877L1.885.511z" />
										</svg>
									</div> <!-- /.icon -->
									<div class="service-contents">
										<p>+60 3-1234 5678</p>
									</div> <!-- /.service-contents-->
								</div> <!-- /.service -->
							</div>
						</div>

						<?php
						if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['contact_submit'])) {
							// Database connection
							$conn = new mysqli("localhost", "root", "", "furni_store");

							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							}

							// Create table if it doesn't exist
							$createTable = "CREATE TABLE IF NOT EXISTS contact_message (
								id INT AUTO_INCREMENT PRIMARY KEY,
								name VARCHAR(100) NOT NULL,
								email VARCHAR(100) NOT NULL,
								message TEXT NOT NULL,
								submitted_at DATETIME NOT NULL
							)";

							if (!$conn->query($createTable)) {
								echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
										Error creating table: ' . $conn->error . '
										<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
									  </div>';
								$conn->close();
								exit;
							}

							// Get and sanitize input
							$fname = $conn->real_escape_string($_POST['fname']);
							$lname = $conn->real_escape_string($_POST['lname']);
							$email = $conn->real_escape_string($_POST['email']);
							$message = $conn->real_escape_string($_POST['message']);
							$name = $fname . " " . $lname;

							// Insert message
							$sql = "INSERT INTO contact_message (name, email, message, submitted_at) 
								   VALUES ('$name', '$email', '$message', NOW())";

							if ($conn->query($sql) === TRUE) {
								echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
										Thank you for your message! We will get back to you soon.
										<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
									  </div>';
							} else {
								echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
										Error: ' . $conn->error . '
										<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
									  </div>';
							}

							$conn->close();
						}
						?>

						<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
							<div class="row">
								<div class="col-6">
									<div class="form-group">
										<label class="text-black" for="fname">First name</label>
										<input type="text" class="form-control" id="fname" name="fname" required>
									</div>
								</div>
								<div class="col-6">
									<div class="form-group">
										<label class="text-black" for="lname">Last name</label>
										<input type="text" class="form-control" id="lname" name="lname" required>
									</div>
								</div>
							</div>
							<div class="form-group">
								<label class="text-black" for="email">Email address</label>
								<input type="email" class="form-control" id="email" name="email" required>
							</div>

							<div class="form-group mb-5">
								<label class="text-black" for="message">Message</label>
								<textarea class="form-control" id="message" name="message" cols="30" rows="5" required></textarea>
							</div>

							<button type="submit" name="contact_submit" class="btn btn-primary-hover-outline">Send Message</button>
						</form>

					</div>

				</div>

			</div>

		</div>


	</div>
	</div>

	<!-- End Contact Form -->



	<!-- Start Footer Section -->
	<footer class="footer-section">
		<div class="container relative">

			<div class="sofa-img">
				<img src="images/sofa.png" alt="Image" class="img-fluid">
			</div>

			<div class="row">
				<div class="col-lg-8">
					<div class="subscription-form">
						<h3 class="d-flex align-items-center">
							<span class="me-1"><img src="./images/envelope-outline.svg" alt="Image" class="img-fluid"></span>
							<span>Subscribe to Newsletter</span>
						</h3>

						<?php
						if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['subscribe'])) {
							// Database connection
							$conn = new mysqli("localhost", "root", "", "furni_store");

							if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
							}

							// Get and sanitize input
							$name = $conn->real_escape_string($_POST['subscriber_name']);
							$email = $conn->real_escape_string($_POST['subscriber_email']);

							// Check if email already exists
							$checkEmail = $conn->query("SELECT email FROM newsletter_subscribers WHERE email = '$email'");

							if ($checkEmail->num_rows > 0) {
								echo '<div class="alert alert-warning alert-dismissible fade show" role="alert" id="subscribeAlert">
										This email is already subscribed!
										<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
									  </div>';
							} else {
								// Insert new subscriber
								$sql = "INSERT INTO newsletter_subscribers (name, email) VALUES ('$name', '$email')";

								if ($conn->query($sql) === TRUE) {
									echo '<div class="alert alert-success alert-dismissible fade show" role="alert" id="subscribeAlert">
											Thank you for subscribing!
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
										  </div>';
								} else {
									echo '<div class="alert alert-danger alert-dismissible fade show" role="alert" id="subscribeAlert">
											Error: ' . $conn->error . '
											<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
										  </div>';
								}
							}



							$conn->close();
						}
						?>

						<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="row g-3">
							<div class="col-auto">
								<input type="text" name="subscriber_name" class="form-control" placeholder="Enter your name" required>
							</div>
							<div class="col-auto">
								<input type="email" name="subscriber_email" class="form-control" placeholder="Enter your email" required>
							</div>
							<div class="col-auto">
								<button type="submit" name="subscribe" class="btn btn-primary">
									<span class="fa fa-paper-plane"></span>
								</button>
							</div>
						</form>

					</div>
				</div>
			</div>

			<div class="row g-5 mb-5">
				<div class="col-lg-4">
					<div class="mb-4 footer-logo-wrap"><a href="#" class="footer-logo">Furni<span>.</span></a></div>
					<p class="mb-4">Furni offers a curated collection of modern, stylish furniture designed to enhance your home. Our high-quality pieces combine comfort and aesthetics, crafted from sustainable materials for durability and eco-friendliness. Transform your living space with Furni’s innovative designs that reflect your unique style.</p>

					<ul class="list-unstyled custom-social">
						<li><a href="#"><span class="fa fa-brands fa-facebook-f"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-twitter"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-instagram"></span></a></li>
						<li><a href="#"><span class="fa fa-brands fa-linkedin"></span></a></li>
					</ul>
				</div>

				<div class="col-lg-8">
					<div class="row links-wrap">
						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">About us</a></li>
								<li><a href="#">Services</a></li>
								<li><a href="#">Blog</a></li>
								<li><a href="#">Contact us</a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#">Support</a></li>
								<li><a href="#">Knowledge base</a></li>
								<li><a href="#">Live chat</a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>

						<div class="col-6 col-sm-6 col-md-3">
							<ul class="list-unstyled">
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
								<li><a href="#"></a></li>
							</ul>
						</div>
					</div>
				</div>

			</div>

			<div class="border-top copyright">
				<div class="row pt-4">
					<div class="col-lg-6">
						<p class="mb-2 text-center text-lg-start">Furni &copy;<script>
								document.write(new Date().getFullYear());
							</script>. All Rights Reserved. &mdash; Designed with love by <a href="#">NABIL</a>
						</p>
					</div>

					<div class="col-lg-6 text-center text-lg-end">
						<ul class="list-unstyled d-inline-flex ms-auto">
							<li class="me-4"><a href="#">Terms &amp; Conditions</a></li>
							<li><a href="#">Privacy Policy</a></li>
						</ul>
					</div>

				</div>
			</div>

		</div>
	</footer>
	<!-- End Footer Section -->


	<script src="js/bootstrap.bundle.min.js"></script>
	<script src="js/tiny-slider.js"></script>
	<script src="js/custom.js"></script>
</body>

</html>